#include <stdlib.h>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cstdlib>
using namespace std;

void insertion_sort(int size)
{
int Arr[size];

for (int i=0;i<size;i++)
	{
	cin>>Arr[i]; //store 5 4 3 2 1
	}
for (int i = 0;i<size-1;i++) // from A[0] to A[3]
{
	for (int j = i+1;j<size;j++) // from A[0] to A[4]
		{
		if (Arr[i]>Arr[j])
			{
			swap(Arr[i],Arr[j]);
			}
		}
}
for (int i=0;i<size;i++)
{
cout<< Arr[i] << endl;
}


}


int main()
{
int size = -1;
while (size!=0)
{
cin>> size;
if (size == 0)
{
break;
}

insertion_sort(size);
}
}
