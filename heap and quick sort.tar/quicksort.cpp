#include <stdlib.h>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cstdlib>
using namespace std;

int Partition(int* A, int p, int r)
{
int x = A[r];
int i = p-1;
for(int j = p;j<=r-1;j++)
	{
	if (A[j]<=x)
		{
		i =i+1;
		swap(A[i],A[j]);
		}
	}
swap(A[i+1],A[r]);
return i+1;
}

void Quicksort(int* A,int p,int r)
{
int q;
if (p<r)
	{
	q = Partition(A,p,r);
	Quicksort(A,p,q-1);
	Quicksort(A,q+1,r);
	}
}

void create(int size)
{
int Arr[size];

for (int i=0;i<size;i++)
	{
	cin>>Arr[i]; //store 5 4 3 2 1
	}
Quicksort(Arr,0,size-1);
for (int i=0;i<size;i++)
{
cout<< Arr[i] << endl;
}
}

int main()
{
int size = -1;
while (size!=0)
{
cin>> size;
if (size == 0)
{
break;
}

create(size);
}
}
