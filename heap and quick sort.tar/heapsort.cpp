#include <stdlib.h>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cstdlib>
using namespace std;

void Heapsort(int*A, int size);
void Build_Max_Heap(int* A, int size);
void Max_Heapify(int* A,int size,int i);


void Make_Arr(int size)
{
int Arr[size+1];

for (int i=1;i<=size;i++)
	{
	cin>>Arr[i]; //store values
	}

Heapsort(Arr,size);

for(int i=1; i<=size;i++)
	{
	cout<<Arr[i]<<endl;
	}
}

void Heapsort(int*A, int size)
{
Build_Max_Heap(A,size);
int temp;
for(int i = size; i>=2;i--)
	{
	temp = A[1];
	A[1] = A[i];
	A[i] = temp;
	size = size - 1;
	Max_Heapify(A,size,1);	
	}
}

void Build_Max_Heap(int* A, int size)
{
for(int i = size/2;i>=1;i--)
	{
	Max_Heapify(A,size,i);
	}
}



void Max_Heapify(int* A,int size,int i)
{
int temp;
int largest;
int l = 2*i;
int r = 2*i + 1;
if (l<=size && A[l]>A[i])
	{
	largest = l;
	}
else
	{
	largest = i;	
	}
if (r <= size && A[r]>A[largest])
	{
	largest = r;
	}
if (largest != i)
	{
	temp = A[i];
	A[i] = A[largest];
	A[largest] = temp;
	Max_Heapify(A,size,largest);
	}
}



int main()
{
int size = -1;
while (size!=0)
{
cin>> size;
if (size == 0)
{
break;
}

Make_Arr(size);
}
return 0;
}
