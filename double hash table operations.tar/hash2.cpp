#include <stdlib.h>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cstdlib>
#include <list>
#include <vector>
#include <iterator> 
using namespace std;

void hash()
{
int arr [13];
int holder;
int hashed;
int i=1;
int m = 1;
int found = 0;
for (int i = 0;i<13;i++)
	{
	arr[i]=-5;
	}
cin>> holder;
while (1)
{
if (holder == -1)
{
break;
}
hashed =holder%13;
	if (arr[hashed] == -5)
	{
		arr[hashed] =holder; 
	}
	else
	{
	i = 1;
		while (arr[hashed]!=-5)
		{
		hashed = holder%13 + i*((holder % 11)+ 1);
		hashed = hashed%13; 
		i++;
		}
		arr[hashed] = holder;	
	}
cin>>holder;
}
for (int i = 0;i<13;i++)
	{
	if (arr[i]!=-5)
		{
	cout<<arr[i]<<endl;
		}
	else
		{
	cout<<endl;
		}
	}
cin>> holder;
while(holder != -2)
{
hashed = holder%13;
found = 0;
while(1)
	{
	if(arr[hashed]==holder)
		{
		found = 1;
		break;		
		}
	else if(holder%13 == (hashed+1)%13)	
		{
		break;
		}
	else
	{
	hashed = (hashed+1)%13;	
	}	
	}
if (found == 1)
{
cout << hashed<<endl;
}
else
{
cout<< "NOT_FOUND"<<endl;
}
cin>>holder;
}
cin>>holder;
while(holder != -3)
{
hashed = holder%13;
found = 0;
while(1)
	{
	if(arr[hashed]==holder)
		{
		arr[hashed]=-5;
		break;		
		}
	else if(holder%13 == (hashed+1)%13)	
		{
		break;
		}
	else
	{
	hashed = (hashed+1)%13;	
	}	
	}
cin>>holder;
}
for (int i = 0;i<13;i++)
	{
	if (arr[i]!=-5)
		{
	cout<<arr[i]<<endl;
		}
	else
		{
	cout<<endl;
		}
	}
}



int main()
{


hash();

return 0;
}

