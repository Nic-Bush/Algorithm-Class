#include <stdlib.h>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cstdlib>
using namespace std;


void func1(int size)
{
int Array[size];
int a;
for (int i=0;i<size;i++)//caps at size - 1
{
cin>>Array[i];//takes array inputs
}
for(int i=0;i<size-1;i++)//for 0 to arr[size-2]
{
if(Array[i+1]<Array[i])
{
cout<<"INCORRECT SEQUENCE"<<endl;
return;
}
}
for(int i=size-1; i>=0;i--)//from size-1 to 0 print in reverse
{
a = Array[i];
cout<<a<<endl;
}
return;
}

int main()
{
int size;
cin>>size;
while(size!=0)
{
func1(size);
cin>>size;
}
}
