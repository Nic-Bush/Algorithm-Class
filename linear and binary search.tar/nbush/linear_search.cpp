#include <stdlib.h>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cstdlib>
using namespace std;
int CreateAndSearch(int size, int key)
{
int i;
int Arr[size];
for (i=0;i<size;i++)
{
cin>> Arr[i];
}
for (i=0; i<size;i++)
{
if (Arr[i]==key)
{
cout<<i<<endl;
return 0;
}
}
cout<<-1<<endl;
return 0;
}



int main()
{
int size = -100;
int key = -100;
int a;
while (size!=0)
{
cin>> size;
if (size == 0)
{
break;
}
cin>> key;
CreateAndSearch(size, key);
}
}
