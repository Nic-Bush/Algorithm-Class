#include <stdlib.h>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cstdlib>
using namespace std;
int BinSearch(int size, int key)
{
int low,mid,high;
low = 0;
high = size-1;
int Arr[size];
for (int i=0;i<size;i++)
{
cin>> Arr[i];
}
while (low<high)
{
mid = ((high + low)/2);
if (Arr[mid]==key)
{
return mid;
}
else if(Arr[mid]>key)
{
high=mid-1;
}
else
{
low= mid + 1;
}
}
if(Arr[high]==key)
{
return high;
}
return -1;
}


main()
{
int size = -100;
int key = -100;
int a;
while (size!=0)
{
cin>> size;
if (size == 0)
{
break;
}
cin>> key;
a = BinSearch(size, key);
cout<<a<<endl;
}
}
