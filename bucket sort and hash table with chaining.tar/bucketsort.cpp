#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cstdlib>
#include <list>
#include <vector>
#include <algorithm>
using namespace std;


void bucketsort(float Arr[], int size)
{
   int store;
    vector<float> buckets[size];
   for (int i = 0; i<size; i++)
   {
   store = (Arr[i]*size);//finds which bucket to store in
   buckets[store].push_back(Arr[i]);//stores in bucket
   }

for(int k= 0; k<size; k++)//sort buckets
{
sort(buckets[k].begin(),buckets[k].end());
}
store = 0;

for (int i = 0; i<size; i++)
{
for(int j = 0; j<buckets[i].size();j++)
{
Arr[store] = buckets[i][j];
store++;
}
}
return;
}


void Make_Arr(int size)
{
float Arr[size];

for (int i=0;i<size;i++)
	{
	cin>>Arr[i]; //store values
	}

bucketsort(Arr,size);

for(int i=0; i<size;i++)
	{
	cout<<Arr[i]<<endl;
	}
return;
}

int main()
{

int size = -1;
while (size!=0)
{
cin>> size;
if (size == 0)
{
break;
}

Make_Arr(size);
}
return 0;
}

