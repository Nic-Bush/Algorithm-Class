#include <stdlib.h>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cstdlib>
#include <list>
#include <vector>
#include <iterator> 
using namespace std;

int search(list<int> table, int current,int finder)
{
int location;
        

location=0;
for(list<int>:: iterator it = table.begin();it!=table.end();advance(it,1))
	{	
	if(*it==current)
		{
		cout<<finder<<","<< location <<endl;
		return 1;
		}
	location++;	
	}
return -1;

}

void Hash(int size)
{
    int store;
    int current;
    int finder;
    int location=0;
    list<int> table [size];
    while(1)//input things
    {
        cin>> current;
        if (current==-1)
        {
            break;
        }
        store = current % size;
        table[store].push_front(current);
    }
    
	for (int i = 0; i<size; i++)
	{
	for(list<int>::iterator it = table[i].begin();it!=table[i].end();advance(it,1))
		{
		cout<<*it<<"->";
		}
	cout<<endl;
	}

    while(1)
{
cin>> current;
    if (current==-2)
        {
            break;
        }
finder = current % size;
location= search(table[finder],current,finder);
if (location==-1)
{
cout<<"NOT_FOUND"<<endl;
}
}

    while (1)//delete function if there
    {
    cin>> current;
    if (current==-3)
        {
            break;
        }
	finder = current % size;
	for(list<int>::iterator it = table[finder].begin();it!=table[finder].end();advance(it,1))
	if(*it==current)
	{
	it = table[finder].erase(it);
	break;
	}    

    }
	for (int i = 0; i<size; i++)
	{
	for(list<int>::iterator it = table[i].begin();it!=table[i].end();advance(it,1))
		{
		cout<<*it<<"->";
		}
	cout<<endl;
	}
return;
}
int main()
{

int size = -1;
while (size!=0)
{
cin>> size;
if (size == 0)
{
break;
}

Hash(size);
}
return 0;
}
