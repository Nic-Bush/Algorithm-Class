#include <iostream>
#include <string>
#include <vector>
#include <math.h>
#include <limits.h>

using namespace std;

int chain_mult(int A[], int i, int j)
{
if (i==j)
{
return 0;
}
 int pos_min;
 int minimum = INT_MAX;
 int number;
 for (int k = i; k<j;k++ )
 {
 pos_min = chain_mult(A,i,k) + chain_mult(A,k+1,j) +A[i-1] *A[k]*A[j];
if (pos_min <minimum)
{
minimum = pos_min;
} 
}
 return minimum;
}



void helper(int N)
{
int A[N+1];
int minimum;
for (int i=0; i<N+1; i++)
{
    cin >> A[i];
}

minimum = chain_mult(A,1,N);

cout<< minimum<<endl;

return;
}






int main()
{

int N;
cin>> N;
while (N != 0)
{
helper(N);
cin>>N;
}
return 0;


}
