#include <iostream>
#include "BST.cpp"
#include <string>
#include <vector>
#include <math.h>
#include <limits.h>
int main()
{
vector<BST*> leaf_holder;
//create a vector of bst and a vector of Nodes and pop things from the vector of Nodes until there are none left adding/replacing the Bst vector(might use a temp BST or something like that and keep replacing till all nodes have been added)
char curr_let;
Node * elements[6];
for (int i=0; i<6;i++)
{
elements[i] = new Node;
elements[i]->Frequency = 0;
}
elements[0]->Letter='A';
elements[1]->Letter='B';
elements[2]->Letter='C';
elements[3]->Letter='D';
elements[4]->Letter='E';
elements[5]->Letter='F';
cin>>curr_let;

while (curr_let != 'Z')
{

    elements[int(curr_let-'A')]->Frequency++;

cin>> curr_let;
}
for(int i=0; i<6;i++)
{
    BST* A = new BST;
    A->Insert(elements[i]->Frequency,elements[i]->Letter);
    leaf_holder.push_back(A);

}


int least = INT_MAX;
int second_least =INT_MAX;
int least_i;
int secondleast_i;

while (leaf_holder.size() > 1)
{
least = INT_MAX;
second_least =INT_MAX;
for (int i = 0;i<leaf_holder.size();i++)
{

    if (((leaf_holder[i]->getRoot())->Frequency) < least)
    {
        secondleast_i = least_i;
        least_i = i;
        second_least = least;
        least = (leaf_holder[i]->getRoot())->Frequency;
    }
    else if (((leaf_holder[i]->getRoot())-> Frequency)<second_least)
    {
        secondleast_i = i;
        second_least = (leaf_holder[i]->getRoot())->Frequency;
    }

}
leaf_holder[secondleast_i]->InsertRightRoot((leaf_holder[least_i]->getRoot())->Frequency, 'Z');
leaf_holder[secondleast_i]->InsertTreeLeft((*leaf_holder[least_i]));
leaf_holder.erase(leaf_holder.begin() + least_i);
}

leaf_holder[0]->PrintLetterFreqs();






}


